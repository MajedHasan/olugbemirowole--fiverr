-- AlterTable
ALTER TABLE `Hospital` MODIFY `email` VARCHAR(191) NULL;
